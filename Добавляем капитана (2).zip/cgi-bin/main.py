from flask import Flask
from data import db_session
from data.users import User


app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


def main():
    db_session.global_init("db/blogs.db")
    user = User()
    user1 = User()
    user2 = User()
    user3 = User()
    user.surname = "Scott"
    user.name = "Ridley"
    user.age = 21
    user.position = 'captain'
    user.speciality = 'research engineer'
    user.address = 'module_1'
    user.email = 'scott_chief@mars.org'
    db_sess = db_session.create_session()
    db_sess.add(user)
    user1.surname = "Cameron"
    user1.name = "James"
    user1.age = 68
    user1.position = 'caretaker'
    user1.speciality = 'engineer 1'
    user1.address = 'module_2'
    user1.email = 'james_1213@mars.org'
    db_sess.add(user1)
    user1.surname = "Cameron"
    user1.name = "James"
    user1.age = 68
    user1.position = 'caretaker'
    user1.speciality = 'engineer 1'
    user1.address = 'module_2'
    user1.email = 'james_1213@mars.org'
    db_sess.add(user1)
    user2.surname = "Steve"
    user2.name = "Eisenberg"
    user2.age = 45
    user2.position = 'assistant captain'
    user2.speciality = 'engineer 2'
    user2.address = 'module_3'
    user2.email = 'jobs_cam@mars.org'
    db_sess.add(user2)
    user3.surname = "John"
    user3.name = "Lennon"
    user3.age = 40
    user3.position = 'assistant'
    user3.speciality = 'engineer 4'
    user3.address = 'module_4'
    user3.email = 'imaginecom@mars.org'
    db_sess.add(user3)
    db_sess.commit()

    #app.run()


if __name__ == '__main__':
    main()