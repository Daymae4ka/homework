from flask import Flask
from flask import url_for
from flask import request
from flask import render_template


app = Flask(__name__)


@app.route('/')
@app.route('/')
def index():
    return "Миссия Колонизация Марса"

@app.route('/index')
def countdown():
    return "И на Марсе будут яблони цвести!"


@app.route('/carousel')
def carousel():
    return f'''<!doctype html>
                <html lang="en">
                  <head>
                    <meta charset="utf-8">
                    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
                    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
                    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
                    <link rel="stylesheet" type="text/css" href="{url_for('static', filename='/css/style.css')}" />
                    <title>Пейзажи Марса</title>
                </head>
                <body>
                 <h1><p align="center">Пейзажи Марса</p></h1>
                <div class="container">
                  <br>
                  <div id="myCarousel" class="carousel slide" data-ride="carousel">
                    <ol class="carousel-indicators">
                      <li data-target="#pic1" data-slide-to="1" class="active"></li>
                      <li data-target="#pic1" data-slide-to="2"></li>
                      <li data-target="#pic1" data-slide-to="3"></li>
                    </ol>
                    <div class="carousel-inner" role="listbox">
                      <div class="item active">
                        <img src="{url_for('static', filename='img/marss3.jpg')}" alt="First slide">
                            <div class="carousel-caption d-none d-md-block">
                            </div>
                      </div>
                      <div class="item">
                        <img src="{url_for('static', filename='img/marss2.jpg')}" alt="Second slide">
                      </div>
                      <div class="item">
                        <img class="d-block w-100" src="{url_for('static', filename='img/marss1.jpg')}" alt="Third slide">
                        <div class="carousel-caption d-none d-md-block">
                        </div>
                    </div>
                    <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
                      <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                      <span class="sr-only">Previous</span>
                    </a>
                    <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
                      <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                      <span class="sr-only">Next</span>
                    </a>
                  </div>
                </div>
                </body>
                </html>
                '''


@app.route('/load_photo')
def photo():
    if request.method == 'GET':
        return f'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Photo</title>
    <link rel="stylesheet" href="style.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.css" type="text/css">
</head>
<body>
    <div id="wrapper">
        
        <div id=header >
            <div class=text>
                <div id=p>
               <p>Photo</p>
           </div>
           <div id=ca>
               <p>Cage app</p>
           </div>
                
            </div>
           
       
       <div class="menu">
              <ul >
               <li ><a href=""><i class="fa fa-home" aria-hidden="true"></i>Home</a></li>
               <li ><a href=""><i class="fa fa-camera" aria-hidden="true"></i>Gallery</a></li>
               <li ><a href=""><i class="fa fa-users" aria-hidden="true"></i>Members</a></li>
               <li ><a href=""><i class="fa fa-power-off " aria-hidden="true"></i>Chekout</a></li>
               
           </ul>
       </div>
        
       
        </div>
        
        <div clas=content>
            
            <div class=text_up>
               <p>Please select an image from your computer</p>
                
            </div>
            
            
            <div class="upload">
                
                <form enctype="multipart/form-data" method="post">
  
   <p><input type="file" name="photo" multiple accept="image/*,image/jpeg">
   <input type="submit" value="Отправить"></p>
                
            </div>
            
        </div>
        
        <div id=images>
            
        </div>
        
        
        </div>
</body>
</html>'''
    elif request.method == 'POST':
        f = request.files['file']
        print(f.read())
        return "Форма отправлена"

if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')