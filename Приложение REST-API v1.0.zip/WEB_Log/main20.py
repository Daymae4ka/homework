from flask import Flask, make_response, render_template, request, session, jsonify
from flask_restful import abort, Api
from werkzeug.utils import redirect

from WEB_Log.data import news_resources
from data.users import User
from data.news import News
from forms.news import NewsForm
from forms.user import RegisterForm
from flask_login import LoginManager, login_user, login_required, logout_user, current_user
from data import db_session
from data import news_api
from loginform import LoginForm
from WEB_Log.data import user_resources


app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'

api = Api(app, catch_all_404s=True)


def main():
    db_session.global_init('db/blogs.db')
    # для списка объектов
    api.add_resource(user_resources.UsersListResource, '/api/v2/users')

    # для одного объекта
    api.add_resource(user_resources.UserResource, '/api/v2/users/<int:user_id>')
    app.run()


if __name__ == '__main__':
    main()
